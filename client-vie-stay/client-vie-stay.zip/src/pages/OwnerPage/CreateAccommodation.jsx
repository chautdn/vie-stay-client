"use client"

import { useState } from "react"
import { useNavigate } from "react-router-dom"
import {
  Building2,
  MapPin,
  Phone,
  ArrowLeft,
  AlertCircle,
  CheckCircle,
  RefreshCw,
  FileText,
  X,
  Clock,
} from "lucide-react"
import { ACCOMMODATION_ROUTES, apiClient } from "../../store/apiRoutes/accommodationRoutes"

function CreateAccommodation() {
  const navigate = useNavigate()
  const [loading, setLoading] = useState(false)
  const [errors, setErrors] = useState({})
  const [success, setSuccess] = useState("")

  // Form state matching your backend model exactly - FIXED STRUCTURE
  const [form, setForm] = useState({
    name: "",
    description: "",
    type: "",
    images: [],
    documents: [], // Required for your backend
    amenities: [],
    // Fixed: Move address and contactInfo to top level
    address: {
      street: "",
      ward: "",
      district: "",
      city: "Đà Nẵng",
      fullAddress: "",
    },
    contactInfo: {
      phone: "",
      email: "",
      website: "",
    },
    totalRooms: 0,
    availableRooms: 0,
    policies: {
      checkInTime: "",
      checkOutTime: "",
      smokingAllowed: false,
      petsAllowed: false,
      partiesAllowed: false,
      quietHours: {
        start: "",
        end: "",
      },
      additionalRules: [], // Fixed: Initialize as empty array
    },
  })

  // Document upload state
  const [documentFiles, setDocumentFiles] = useState([])
  const [uploadingDocuments, setUploadingDocuments] = useState(false)

  // Replace with actual owner ID from your auth system
  const ownerId = "675f7c5b4c57ca2d5e8b4567"

  // Accommodation types from your backend model
  const accommodationTypes = [
    { value: "duplex", label: "Duplex" },
    { value: "house", label: "Nhà riêng" },
    { value: "apartment_building", label: "Chung cư" },
    { value: "hotel", label: "Khách sạn" },
    { value: "motel", label: "Nhà nghỉ" },
    { value: "hostel", label: "Hostel" },
    { value: "guesthouse", label: "Nhà trọ" },
    { value: "resort", label: "Resort" },
    { value: "villa", label: "Villa" },
    { value: "homestay", label: "Homestay" },
  ]

  // Districts from your backend model
  const districts = [
    "Quận Hải Châu",
    "Quận Thanh Khê",
    "Quận Sơn Trà",
    "Quận Ngũ Hành Sơn",
    "Quận Liên Chiểu",
    "Quận Cẩm Lệ",
    "Huyện Hòa Vang",
    "Huyện Hoàng Sa",
  ]

  // Amenities from your backend model
  const amenitiesList = [
    { value: "wifi", label: "WiFi" },
    { value: "parking", label: "Chỗ đậu xe" },
    { value: "pool", label: "Hồ bơi" },
    { value: "gym", label: "Phòng gym" },
    { value: "laundry", label: "Giặt ủi" },
    { value: "elevator", label: "Thang máy" },
    { value: "security", label: "Bảo vệ 24/7" },
    { value: "air_conditioning", label: "Điều hòa" },
    { value: "heating", label: "Sưởi ấm" },
    { value: "kitchen", label: "Bếp" },
    { value: "restaurant", label: "Nhà hàng" },
    { value: "bar", label: "Quầy bar" },
    { value: "garden", label: "Vườn" },
    { value: "terrace", label: "Sân thượng" },
    { value: "balcony", label: "Ban công" },
    { value: "sea_view", label: "View biển" },
    { value: "mountain_view", label: "View núi" },
    { value: "pets_allowed", label: "Cho phép thú cưng" },
    { value: "smoking_allowed", label: "Cho phép hút thuốc" },
    { value: "wheelchair_accessible", label: "Tiếp cận xe lăn" },
  ]

  // Document types from your backend model
  const documentTypes = [
    { value: "business_license", label: "Giấy phép kinh doanh" },
    { value: "property_deed", label: "Sổ đỏ/Giấy chứng nhận quyền sử dụng đất" },
    { value: "tax_certificate", label: "Giấy chứng nhận thuế" },
    { value: "fire_safety", label: "Giấy chứng nhận PCCC" },
    { value: "other", label: "Khác" },
  ]

  // Required document types (excluding "other")
  const requiredDocTypes = ["business_license", "property_deed", "tax_certificate", "fire_safety"]

  // Document helper functions
  const addDocumentByType = (type, label) => {
    const url = prompt(`Nhập URL cho ${label}:`)
    const fileName = prompt(`Nhập tên file cho ${label}:`)

    if (url && fileName) {
      // Remove existing document of same type first
      const filteredDocs = form.documents.filter((doc) => doc.type !== type)

      setForm((prev) => ({
        ...prev,
        documents: [
          ...filteredDocs,
          {
            type,
            url: url.trim(),
            fileName: fileName.trim(),
            uploadedAt: new Date().toISOString(),
          },
        ],
      }))
    }
  }

  const editDocument = (type) => {
    const existingDoc = form.documents.find((doc) => doc.type === type)
    if (!existingDoc) return

    const docTypeLabel = documentTypes.find((t) => t.value === type)?.label || type
    const newUrl = prompt(`Chỉnh sửa URL cho ${docTypeLabel}:`, existingDoc.url)
    const newFileName = prompt(`Chỉnh sửa tên file cho ${docTypeLabel}:`, existingDoc.fileName)

    if (newUrl && newFileName) {
      setForm((prev) => ({
        ...prev,
        documents: prev.documents.map((doc) =>
          doc.type === type ? { ...doc, url: newUrl.trim(), fileName: newFileName.trim() } : doc,
        ),
      }))
    }
  }

  const removeDocumentByType = (type) => {
    const docTypeLabel = documentTypes.find((t) => t.value === type)?.label || type
    if (window.confirm(`Bạn có chắc muốn xóa ${docTypeLabel}?`)) {
      setForm((prev) => ({
        ...prev,
        documents: prev.documents.filter((doc) => doc.type !== type),
      }))
    }
  }

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target
    const keys = name.split(".")

    if (keys.length === 1) {
      setForm((prev) => ({
        ...prev,
        [name]: type === "checkbox" ? checked : type === "number" ? Number(value) : value,
      }))
    } else if (keys.length === 2) {
      setForm((prev) => ({
        ...prev,
        [keys[0]]: {
          ...prev[keys[0]],
          [keys[1]]: type === "checkbox" ? checked : type === "number" ? Number(value) : value,
        },
      }))
    } else if (keys.length === 3) {
      setForm((prev) => ({
        ...prev,
        [keys[0]]: {
          ...prev[keys[0]],
          [keys[1]]: {
            ...prev[keys[0]][keys[1]],
            [keys[2]]: type === "checkbox" ? checked : type === "number" ? Number(value) : value,
          },
        },
      }))
    }

    // Clear error when user starts typing
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: "" }))
    }
  }

  const handleAmenityChange = (amenityValue) => {
    setForm((prev) => ({
      ...prev,
      amenities: prev.amenities.includes(amenityValue)
        ? prev.amenities.filter((a) => a !== amenityValue)
        : [...prev.amenities, amenityValue],
    }))
  }

  const handleRuleAdd = () => {
    const rule = prompt("Nhập quy định mới:")
    if (rule && rule.trim()) {
      setForm((prev) => ({
        ...prev,
        policies: {
          ...prev.policies,
          additionalRules: [...(prev.policies.additionalRules || []), rule.trim()],
        },
      }))
    }
  }

  const handleRuleRemove = (index) => {
    setForm((prev) => ({
      ...prev,
      policies: {
        ...prev.policies,
        additionalRules: (prev.policies.additionalRules || []).filter((_, i) => i !== index),
      },
    }))
  }

  // Document upload handlers
  const handleDocumentFileChange = (e) => {
    const files = Array.from(e.target.files)
    setDocumentFiles((prev) => [...prev, ...files])
  }

  const removeDocumentFile = (index) => {
    setDocumentFiles((prev) => prev.filter((_, i) => i !== index))
  }

  const addDocumentUrl = () => {
    const type = prompt(
      "Chọn loại giấy tờ:\n1. business_license\n2. property_deed\n3. tax_certificate\n4. fire_safety\n5. other",
    )
    const url = prompt("Nhập URL của giấy tờ:")
    const fileName = prompt("Nhập tên file:")

    if (type && url && fileName) {
      const validTypes = ["business_license", "property_deed", "tax_certificate", "fire_safety", "other"]
      if (validTypes.includes(type)) {
        setForm((prev) => ({
          ...prev,
          documents: [
            ...prev.documents,
            {
              type,
              url,
              fileName,
              uploadedAt: new Date().toISOString(),
            },
          ],
        }))
      } else {
        alert("Loại giấy tờ không hợp lệ!")
      }
    }
  }

  const removeDocument = (index) => {
    setForm((prev) => ({
      ...prev,
      documents: prev.documents.filter((_, i) => i !== index),
    }))
  }

  const validateForm = () => {
    const newErrors = {}

    // Required fields from your backend model
    if (!form.name.trim()) newErrors.name = "Tên nhà trọ là bắt buộc"
    if (!form.type) newErrors.type = "Loại hình là bắt buộc"
    if (!form.contactInfo.phone.trim()) newErrors["contactInfo.phone"] = "Số điện thoại là bắt buộc"
    if (!form.address.street.trim()) newErrors["address.street"] = "Địa chỉ là bắt buộc"
    if (!form.address.ward.trim()) newErrors["address.ward"] = "Phường/Xã là bắt buộc"
    if (!form.address.district) newErrors["address.district"] = "Quận/Huyện là bắt buộc"
    if (!form.address.fullAddress.trim()) newErrors["address.fullAddress"] = "Địa chỉ đầy đủ là bắt buộc"

    // Phone validation matching your backend regex
    const phoneRegex = /^(\+84|0)[0-9]{9,10}$/
    if (form.contactInfo.phone && !phoneRegex.test(form.contactInfo.phone)) {
      newErrors["contactInfo.phone"] = "Số điện thoại không hợp lệ (VD: 0123456789)"
    }

    // Email validation matching your backend regex
    if (form.contactInfo.email) {
      const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/
      if (!emailRegex.test(form.contactInfo.email)) {
        newErrors["contactInfo.email"] = "Email không hợp lệ"
      }
    }

    // Room validation
    if (form.totalRooms < 0) newErrors.totalRooms = "Số phòng không thể âm"
    if (form.availableRooms < 0) newErrors.availableRooms = "Số phòng trống không thể âm"
    if (form.availableRooms > form.totalRooms) {
      newErrors.availableRooms = "Số phòng trống không thể lớn hơn tổng số phòng"
    }

    // Time validation for policies
    const timeRegex = /^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/
    if (form.policies.checkInTime && !timeRegex.test(form.policies.checkInTime)) {
      newErrors["policies.checkInTime"] = "Thời gian check-in không hợp lệ (HH:MM)"
    }
    if (form.policies.checkOutTime && !timeRegex.test(form.policies.checkOutTime)) {
      newErrors["policies.checkOutTime"] = "Thời gian check-out không hợp lệ (HH:MM)"
    }
    if (form.policies.quietHours.start && !timeRegex.test(form.policies.quietHours.start)) {
      newErrors["policies.quietHours.start"] = "Thời gian bắt đầu giờ yên tĩnh không hợp lệ (HH:MM)"
    }
    if (form.policies.quietHours.end && !timeRegex.test(form.policies.quietHours.end)) {
      newErrors["policies.quietHours.end"] = "Thời gian kết thúc giờ yên tĩnh không hợp lệ (HH:MM)"
    }

    // Document validation - Only 4 main document types required (excluding "other")
    const requiredDocTypes = ["business_license", "property_deed", "tax_certificate", "fire_safety"]
    const missingDocTypes = requiredDocTypes.filter((type) => !form.documents.find((doc) => doc.type === type))

    if (missingDocTypes.length > 0) {
      const missingLabels = missingDocTypes
        .map((type) => documentTypes.find((dt) => dt.value === type)?.label || type)
        .join(", ")
      newErrors.documents = `Thiếu các loại giấy tờ: ${missingLabels}`
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setSuccess("")
    setErrors({})

    if (!validateForm()) {
      return
    }

    setLoading(true)

    try {
      const formData = {
        ...form,
        ownerId,
        approvalStatus: "pending",
        isActive: true,
      }

      console.log("Submitting form data:", formData)

      const response = await apiClient.post(ACCOMMODATION_ROUTES.CREATE, formData)
      console.log("Create response:", response)

      setSuccess("Tạo nhà trọ thành công! Đang chờ admin duyệt.")

      // Reset form
      setTimeout(() => {
        navigate("/owner/accommodations")
      }, 2000)
    } catch (err) {
      console.error("Create error:", err)
      setErrors({ submit: `Có lỗi xảy ra khi tạo nhà trọ: ${err.message}` })
    } finally {
      setLoading(false)
    }
  }

  
  const getError = (field) => errors[field]

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center space-x-4 mb-4">
          <button
            onClick={() => navigate("/owner/accommodations")}
            className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Tạo nhà trọ mới</h1>
            <p className="text-gray-600">Điền đầy đủ thông tin để tạo nhà trọ mới</p>
          </div>
        </div>
      </div>

      {/* Success Message */}
      {success && (
        <div className="bg-green-50 border border-green-200 rounded-xl p-4 mb-6">
          <div className="flex items-start">
            <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 mr-3 flex-shrink-0" />
            <div>
              <h3 className="text-green-800 font-medium">Thành công!</h3>
              <p className="text-green-700 text-sm mt-1">{success}</p>
            </div>
          </div>
        </div>
      )}

      {/* Submit Error */}
      {errors.submit && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 mb-6">
          <div className="flex items-start">
            <AlertCircle className="h-5 w-5 text-red-500 mt-0.5 mr-3 flex-shrink-0" />
            <div>
              <h3 className="text-red-800 font-medium">Lỗi</h3>
              <p className="text-red-700 text-sm mt-1">{errors.submit}</p>
            </div>
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Basic Information */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center mb-6">
            <Building2 className="h-5 w-5 text-blue-600 mr-2" />
            <h2 className="text-xl font-semibold text-gray-900">Thông tin cơ bản</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Tên nhà trọ *</label>
              <input
                type="text"
                name="name"
                value={form.name}
                onChange={handleChange}
                maxLength={200}
                className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                  getError("name") ? "border-red-300" : "border-gray-300"
                }`}
                placeholder="VD: Nhà trọ Hải Châu"
              />
              {getError("name") && (
                <p className="mt-1 text-sm text-red-600 flex items-center">
                  <AlertCircle className="h-4 w-4 mr-1" />
                  {getError("name")}
                </p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Loại hình *</label>
              <select
                name="type"
                value={form.type}
                onChange={handleChange}
                className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                  getError("type") ? "border-red-300" : "border-gray-300"
                }`}
              >
                <option value="">Chọn loại hình</option>
                {accommodationTypes.map((type) => (
                  <option key={type.value} value={type.value}>
                    {type.label}
                  </option>
                ))}
              </select>
              {getError("type") && (
                <p className="mt-1 text-sm text-red-600 flex items-center">
                  <AlertCircle className="h-4 w-4 mr-1" />
                  {getError("type")}
                </p>
              )}
            </div>
          </div>

          <div className="mt-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">Mô tả</label>
            <textarea
              name="description"
              value={form.description}
              onChange={handleChange}
              rows={4}
              maxLength={2000}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Mô tả chi tiết về nhà trọ, tiện nghi, vị trí..."
            />
            <p className="text-xs text-gray-500 mt-1">{form.description.length}/2000 ký tự</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Tổng số phòng</label>
              <input
                type="number"
                name="totalRooms"
                value={form.totalRooms}
                onChange={handleChange}
                min="0"
                className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                  getError("totalRooms") ? "border-red-300" : "border-gray-300"
                }`}
              />
              {getError("totalRooms") && (
                <p className="mt-1 text-sm text-red-600 flex items-center">
                  <AlertCircle className="h-4 w-4 mr-1" />
                  {getError("totalRooms")}
                </p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Số phòng trống</label>
              <input
                type="number"
                name="availableRooms"
                value={form.availableRooms}
                onChange={handleChange}
                min="0"
                max={form.totalRooms}
                className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                  getError("availableRooms") ? "border-red-300" : "border-gray-300"
                }`}
              />
              {getError("availableRooms") && (
                <p className="mt-1 text-sm text-red-600 flex items-center">
                  <AlertCircle className="h-4 w-4 mr-1" />
                  {getError("availableRooms")}
                </p>
              )}
            </div>
          </div>
        </div>

        {/* Address Information */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center mb-6">
            <MapPin className="h-5 w-5 text-blue-600 mr-2" />
            <h2 className="text-xl font-semibold text-gray-900">Địa chỉ</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Địa chỉ *</label>
              <input
                type="text"
                name="address.street"
                value={form.address.street}
                onChange={handleChange}
                maxLength={200}
                className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                  getError("address.street") ? "border-red-300" : "border-gray-300"
                }`}
                placeholder="Số nhà, tên đường"
              />
              {getError("address.street") && (
                <p className="mt-1 text-sm text-red-600 flex items-center">
                  <AlertCircle className="h-4 w-4 mr-1" />
                  {getError("address.street")}
                </p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Phường/Xã *</label>
              <input
                type="text"
                name="address.ward"
                value={form.address.ward}
                onChange={handleChange}
                maxLength={100}
                className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                  getError("address.ward") ? "border-red-300" : "border-gray-300"
                }`}
                placeholder="Tên phường/xã"
              />
              {getError("address.ward") && (
                <p className="mt-1 text-sm text-red-600 flex items-center">
                  <AlertCircle className="h-4 w-4 mr-1" />
                  {getError("address.ward")}
                </p>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Quận/Huyện *</label>
              <select
                name="address.district"
                value={form.address.district}
                onChange={handleChange}
                className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                  getError("address.district") ? "border-red-300" : "border-gray-300"
                }`}
              >
                <option value="">Chọn quận/huyện</option>
                {districts.map((district) => (
                  <option key={district} value={district}>
                    {district}
                  </option>
                ))}
              </select>
              {getError("address.district") && (
                <p className="mt-1 text-sm text-red-600 flex items-center">
                  <AlertCircle className="h-4 w-4 mr-1" />
                  {getError("address.district")}
                </p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Thành phố</label>
              <input
                type="text"
                name="address.city"
                value={form.address.city}
                onChange={handleChange}
                disabled
                className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 text-gray-500"
              />
            </div>
          </div>

          <div className="mt-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">Địa chỉ đầy đủ *</label>
            <input
              type="text"
              name="address.fullAddress"
              value={form.address.fullAddress}
              onChange={handleChange}
              className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                getError("address.fullAddress") ? "border-red-300" : "border-gray-300"
              }`}
              placeholder="Địa chỉ đầy đủ để khách hàng dễ tìm"
            />
            {getError("address.fullAddress") && (
              <p className="mt-1 text-sm text-red-600 flex items-center">
                <AlertCircle className="h-4 w-4 mr-1" />
                {getError("address.fullAddress")}
              </p>
            )}
          </div>
        </div>

        {/* Contact Information */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center mb-6">
            <Phone className="h-5 w-5 text-blue-600 mr-2" />
            <h2 className="text-xl font-semibold text-gray-900">Thông tin liên hệ</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Số điện thoại *</label>
              <input
                type="tel"
                name="contactInfo.phone"
                value={form.contactInfo.phone}
                onChange={handleChange}
                className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                  getError("contactInfo.phone") ? "border-red-300" : "border-gray-300"
                }`}
                placeholder="0123456789 hoặc +84123456789"
              />
              {getError("contactInfo.phone") && (
                <p className="mt-1 text-sm text-red-600 flex items-center">
                  <AlertCircle className="h-4 w-4 mr-1" />
                  {getError("contactInfo.phone")}
                </p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
              <input
                type="email"
                name="contactInfo.email"
                value={form.contactInfo.email}
                onChange={handleChange}
                className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                  getError("contactInfo.email") ? "border-red-300" : "border-gray-300"
                }`}
                placeholder="example@email.com"
              />
              {getError("contactInfo.email") && (
                <p className="mt-1 text-sm text-red-600 flex items-center">
                  <AlertCircle className="h-4 w-4 mr-1" />
                  {getError("contactInfo.email")}
                </p>
              )}
            </div>
          </div>

          <div className="mt-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">Website</label>
            <input
              type="url"
              name="contactInfo.website"
              value={form.contactInfo.website}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="https://example.com"
            />
          </div>
        </div>

        {/* Policies */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center mb-6">
            <Clock className="h-5 w-5 text-blue-600 mr-2" />
            <h2 className="text-xl font-semibold text-gray-900">Chính sách</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Giờ check-in</label>
              <input
                type="time"
                name="policies.checkInTime"
                value={form.policies.checkInTime}
                onChange={handleChange}
                className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                  getError("policies.checkInTime") ? "border-red-300" : "border-gray-300"
                }`}
              />
              {getError("policies.checkInTime") && (
                <p className="mt-1 text-sm text-red-600 flex items-center">
                  <AlertCircle className="h-4 w-4 mr-1" />
                  {getError("policies.checkInTime")}
                </p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Giờ check-out</label>
              <input
                type="time"
                name="policies.checkOutTime"
                value={form.policies.checkOutTime}
                onChange={handleChange}
                className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                  getError("policies.checkOutTime") ? "border-red-300" : "border-gray-300"
                }`}
              />
              {getError("policies.checkOutTime") && (
                <p className="mt-1 text-sm text-red-600 flex items-center">
                  <AlertCircle className="h-4 w-4 mr-1" />
                  {getError("policies.checkOutTime")}
                </p>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Giờ yên tĩnh - Bắt đầu</label>
              <input
                type="time"
                name="policies.quietHours.start"
                value={form.policies.quietHours.start}
                onChange={handleChange}
                className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                  getError("policies.quietHours.start") ? "border-red-300" : "border-gray-300"
                }`}
              />
              {getError("policies.quietHours.start") && (
                <p className="mt-1 text-sm text-red-600 flex items-center">
                  <AlertCircle className="h-4 w-4 mr-1" />
                  {getError("policies.quietHours.start")}
                </p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Giờ yên tĩnh - Kết thúc</label>
              <input
                type="time"
                name="policies.quietHours.end"
                value={form.policies.quietHours.end}
                onChange={handleChange}
                className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                  getError("policies.quietHours.end") ? "border-red-300" : "border-gray-300"
                }`}
              />
              {getError("policies.quietHours.end") && (
                <p className="mt-1 text-sm text-red-600 flex items-center">
                  <AlertCircle className="h-4 w-4 mr-1" />
                  {getError("policies.quietHours.end")}
                </p>
              )}
            </div>
          </div>

          <div className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  name="policies.smokingAllowed"
                  checked={form.policies.smokingAllowed}
                  onChange={handleChange}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <span className="text-sm text-gray-700">Cho phép hút thuốc</span>
              </label>

              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  name="policies.petsAllowed"
                  checked={form.policies.petsAllowed}
                  onChange={handleChange}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <span className="text-sm text-gray-700">Cho phép thú cưng</span>
              </label>

              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  name="policies.partiesAllowed"
                  checked={form.policies.partiesAllowed}
                  onChange={handleChange}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <span className="text-sm text-gray-700">Cho phép tổ chức tiệc</span>
              </label>
            </div>
          </div>

          <div className="mt-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">Quy định bổ sung</label>
            <div className="space-y-2">
              {(form.policies.additionalRules || []).map((rule, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <span className="flex-1 px-3 py-2 bg-gray-50 rounded-lg text-sm">{rule}</span>
                  <button
                    type="button"
                    onClick={() => handleRuleRemove(index)}
                    className="p-2 text-red-500 hover:bg-red-50 rounded-lg"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>
              ))}
              <button
                type="button"
                onClick={handleRuleAdd}
                className="px-4 py-2 text-blue-600 border border-blue-300 rounded-lg hover:bg-blue-50 transition-colors"
              >
                + Thêm quy định
              </button>
            </div>
          </div>
        </div>

        {/* Amenities */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center mb-6">
            <Building2 className="h-5 w-5 text-blue-600 mr-2" />
            <h2 className="text-xl font-semibold text-gray-900">Tiện nghi</h2>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
            {amenitiesList.map((amenity) => (
              <label key={amenity.value} className="flex items-center space-x-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={form.amenities.includes(amenity.value)}
                  onChange={() => handleAmenityChange(amenity.value)}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <span className="text-sm text-gray-700">{amenity.label}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Documents Upload - Required */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center mb-6">
            <FileText className="h-5 w-5 text-blue-600 mr-2" />
            <h2 className="text-xl font-semibold text-gray-900">Giấy tờ pháp lý *</h2>
            <span className="ml-2 text-sm text-red-600 font-medium">(Bắt buộc 4 loại chính)</span>
          </div>

          {getError("documents") && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg">
              <p className="text-sm text-red-600 flex items-center">
                <AlertCircle className="h-4 w-4 mr-1" />
                {getError("documents")}
              </p>
            </div>
          )}

          <div className="space-y-6">
            {/* Document Type Cards */}
            {documentTypes.map((docType) => {
              const hasDoc = form.documents.find((doc) => doc.type === docType.value)
              const isRequired = docType.value !== "other" // "Khác" không bắt buộc

              return (
                <div
                  key={docType.value}
                  className={`border-2 rounded-lg p-4 transition-all ${
                    hasDoc
                      ? "border-green-300 bg-green-50"
                      : isRequired
                        ? "border-red-300 bg-red-50 hover:border-red-400"
                        : "border-gray-200 bg-gray-50 hover:border-blue-300"
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <FileText
                          className={`h-4 w-4 ${
                            hasDoc ? "text-green-600" : isRequired ? "text-red-500" : "text-gray-400"
                          }`}
                        />
                        <h4 className="font-medium text-sm text-gray-900">{docType.label}</h4>
                        {hasDoc ? (
                          <CheckCircle className="h-4 w-4 text-green-600" />
                        ) : isRequired ? (
                          <AlertCircle className="h-4 w-4 text-red-500" />
                        ) : null}
                        <span
                          className={`text-xs px-2 py-1 rounded-full ${
                            hasDoc
                              ? "bg-green-100 text-green-800"
                              : isRequired
                                ? "bg-red-100 text-red-800"
                                : "bg-gray-100 text-gray-600"
                          }`}
                        >
                          {hasDoc ? "Đã có" : isRequired ? "Bắt buộc" : "Tùy chọn"}
                        </span>
                      </div>

                      {hasDoc ? (
                        <div className="space-y-2">
                          <p className="text-xs text-gray-600 truncate">{hasDoc.fileName}</p>
                          <p className="text-xs text-blue-600 truncate">{hasDoc.url}</p>
                          <div className="flex space-x-2">
                            <button
                              type="button"
                              onClick={() => editDocument(docType.value)}
                              className="text-xs text-blue-600 hover:text-blue-800"
                            >
                              Chỉnh sửa
                            </button>
                            <button
                              type="button"
                              onClick={() => removeDocumentByType(docType.value)}
                              className="text-xs text-red-600 hover:text-red-800"
                            >
                              Xóa
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div>
                          <p className={`text-xs mb-2 ${isRequired ? "text-red-600" : "text-gray-500"}`}>
                            {isRequired ? "Chưa có giấy tờ này" : "Có thể bỏ qua"}
                          </p>
                          <button
                            type="button"
                            onClick={() => addDocumentByType(docType.value, docType.label)}
                            className={`text-sm px-3 py-1 rounded font-medium transition-colors ${
                              isRequired
                                ? "text-white bg-red-500 hover:bg-red-600"
                                : "text-blue-600 bg-blue-50 hover:bg-blue-100"
                            }`}
                          >
                            {isRequired ? "+ Thêm ngay" : "+ Thêm (tùy chọn)"}
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )
            })}

            {/* Summary */}
            <div
              className={`border rounded-lg p-4 ${
                requiredDocTypes.every((type) => form.documents.find((doc) => doc.type === type))
                  ? "bg-green-50 border-green-200"
                  : "bg-red-50 border-red-200"
              }`}
            >
              <div className="flex items-center space-x-2">
                <FileText
                  className={`h-5 w-5 ${
                    requiredDocTypes.every((type) => form.documents.find((doc) => doc.type === type))
                      ? "text-green-600"
                      : "text-red-600"
                  }`}
                />
                <div>
                  <p
                    className={`text-sm font-medium ${
                      requiredDocTypes.every((type) => form.documents.find((doc) => doc.type === type))
                        ? "text-green-900"
                        : "text-red-900"
                    }`}
                  >
                    Bắt buộc:{" "}
                    {requiredDocTypes.filter((type) => form.documents.find((doc) => doc.type === type)).length}/4 loại
                    {form.documents.find((doc) => doc.type === "other") && " + 1 tùy chọn"}
                  </p>
                  <p
                    className={`text-xs mt-1 ${
                      requiredDocTypes.every((type) => form.documents.find((doc) => doc.type === type))
                        ? "text-green-700"
                        : "text-red-700"
                    }`}
                  >
                    {requiredDocTypes.every((type) => form.documents.find((doc) => doc.type === type))
                      ? "✅ Đã đủ tất cả loại giấy tờ bắt buộc"
                      : `⚠️ Còn thiếu ${4 - requiredDocTypes.filter((type) => form.documents.find((doc) => doc.type === type)).length} loại bắt buộc`}
                  </p>

                  {/* Show missing required document types */}
                  {!requiredDocTypes.every((type) => form.documents.find((doc) => doc.type === type)) && (
                    <div className="mt-2">
                      <p className="text-xs text-red-600 font-medium">Còn thiếu:</p>
                      <ul className="text-xs text-red-600 mt-1 space-y-1">
                        {requiredDocTypes
                          .filter((type) => !form.documents.find((doc) => doc.type === type))
                          .map((type) => (
                            <li key={type}>• {documentTypes.find((dt) => dt.value === type)?.label}</li>
                          ))}
                      </ul>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Submit Buttons */}
        <div className="flex justify-end space-x-4 pb-8">
          <button
            type="button"
            onClick={() => navigate("/owner/accommodations")}
            className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
          >
            Hủy
          </button>
          <button
            type="submit"
            disabled={loading}
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center"
          >
            {loading && <RefreshCw className="animate-spin h-4 w-4 mr-2" />}
            {loading ? "Đang tạo..." : "Tạo nhà trọ"}
          </button>
        </div>
      </form>
    </div>
  )
}

export default CreateAccommodation
